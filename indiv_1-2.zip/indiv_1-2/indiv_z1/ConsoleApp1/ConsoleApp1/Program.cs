﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string filePath = "text.txt";

            if (!File.Exists(filePath))
            {
                Console.WriteLine("файл не найден.");
                Console.ReadKey();
                return;
            }

            string text = File.ReadAllText(filePath);
            Stack stack = new Stack();
            string word = "aeiouAEIOU";

            foreach (char c in text)
            {
                if (word.Contains(c))
                {
                    stack.Push(c);
                }
            }

            Console.WriteLine("гласные буквы в обратном порядке:");
            while (!stack.IsEmpty())
            {
                Console.Write(stack.Pop());
            }

            Console.WriteLine();
            Console.Read();
        }
    }
}
