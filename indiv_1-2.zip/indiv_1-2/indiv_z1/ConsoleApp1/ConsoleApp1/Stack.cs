﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Stack
    {
        private List<char> elements = new List<char>();

        public void Push(char i)
        {
            elements.Add(i);
        }

        public char Pop()
        {
            if (elements.Count == 0)
                throw new InvalidOperationException("empty");

            char i = elements[elements.Count - 1];
            elements.RemoveAt(elements.Count - 1);
            return i;
        }

        public bool IsEmpty()
        {
            return elements.Count == 0;
        }
    }
}
