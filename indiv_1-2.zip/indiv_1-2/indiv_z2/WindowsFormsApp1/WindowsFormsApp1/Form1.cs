﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string filePath = openFileDialog.FileName;
                string formula = File.ReadAllText(filePath).Trim();
                textBox1.Text = formula;

                try
                {
                    int result = PFormula(formula);
                    label1.Text = $"Результат формулы: {result}";
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка вычисления формулы: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        static int PFormula(string formula)
        {
            formula = formula.Replace(" ", string.Empty);
            formula = formula.Trim();

            if (char.IsDigit(formula[0]))
            {
                return int.Parse(formula);
            }

            if (formula.StartsWith("p(") || formula.StartsWith("m("))
            {
                char operation = formula[0];
                int commaIndex = FindIndex(formula);
                string leftPart = formula.Substring(2, commaIndex - 2).Trim();
                string rightPart = formula.Substring(commaIndex + 1, formula.Length - commaIndex - 2).Trim();

                int leftValue = PFormula(leftPart);
                int rightValue = PFormula(rightPart);

                if (operation == 'p')
                {
                    return (leftValue + rightValue) % 10;
                }
                else if (operation == 'm')
                {
                    return (leftValue - rightValue + 10) % 10;
                }
            }

            throw new ArgumentException("Неверный формат формулы");
        }

        static int FindIndex(string formula)
        {
            int depth = 0;

            for (int i = 2; i < formula.Length - 1; i++)
            {
                if (formula[i] == '(')
                {
                    depth++;
                }
                else if (formula[i] == ')')
                {
                    depth--;
                }
                else if (formula[i] == ',' && depth == 0)
                {
                    return i;
                }
            }

            throw new ArgumentException("Неверный формат формулы");
        }
    }
}
